<?php
/*
* The footer for our theme
* footer content.
*
* @package design+code demo
* @since 1.0.0
*/
?>

        </div>
 <!-- closing tag for site-content"> -->
        <footer> </footer>
        <?php wp_footer(); ?>
    </body>
</html>