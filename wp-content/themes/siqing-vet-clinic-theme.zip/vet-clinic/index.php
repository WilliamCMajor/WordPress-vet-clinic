<?php
/* 
** This is main default template - required for a theme to be functional
* @package Design+Code Demo
* @Since 1.0.0
*/

get_header();

?>

<main>
    <h1>Hello!</h1>
</main>

<?php get_footer(); ?>